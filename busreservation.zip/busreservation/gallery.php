<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Welcome to CKRT Bus Services</title>
<link rel="stylesheet" type="text/css" href="xres/css/style.css" />
<link rel="icon" type="image/png" href="xres/images/favicon.png" />
<link type="text/css" href="css/styles.css" rel="stylesheet" media="all" />
<script type="text/javascript" src="js/sagallery.js"></script>
<script src="js/jquery.quicksand.js" type="text/javascript"></script>
<script src="js/jquery.easing.js" type="text/javascript"></script>
<script src="js/script.js" type="text/javascript"></script>
<script src="js/jquery.prettyPhoto.js" type="text/javascript"></script> 
<link href="css/prettyPhoto.css" rel="stylesheet" type="text/css" />
<style>
body {
  background-image: url('download.jpg');background-repeat: no-repeat;
  background-attachment: fixed; 
  background-size: 100% 100%;
}
</style>
</head>

<body>
<div id="wrapper">
	<div id="header">
    <h1></h1>
        <ul id="mainnav">
			<li><a href="index.php"style="color:white;">Home</a></li>
            <li class="current"><a href="gallery.php"style="color:white;">Gallery</a></li>
            <li><a href="history.php"style="color:white;">History</a></li>
            <li><a href="routes.php"style="color:white;">Routes</a></li>
            <li><a href="location.php"style="color:white;">location</a></li>
            <li><a href="contact.php"style="color:white;">Contact Us</a></li>
    	</ul>
	</div>
    <div id="content">
    	<div id="gallerycontainer">
			<ul class="portfolio-categ filter">
				<li><b>Categories:<b></li>
				<li class="all active"><a href="#">All</a></li>
				<li class="cat-item-1"><a href="#" title="Category 1">Category 1</a></li>
				<li class="cat-item-2"><a href="#" title="Category 2">Category 2</a></li>
				<li class="cat-item-3"><a href="#" title="Category 3">Category 3</a></li>
				<li class="cat-item-4"><a href="#" title="Category 4">Category 4</a></li>
			</ul>
			<ul class="portfolio-area" style="width: 860px;">	
 		
               		<li class="portfolio-item2" data-id="id-0" data-type="cat-item-4">	
			        <div>
                   <span class="image-block">
					<a class="image-zoom" href="images/big/pic1.jpg"  title="goa"><img width="225" height="140" src="images/thumbs/p1.jpg" alt="Wall-E" title="Goa" />                    
                    </a>
                    </span>
                   <div class="home-portfolio-text">
					<h2 class="post-title-portfolio"><a href="#" rel="bookmark" title="Goa">&nbsp;&nbsp;Mumbai tor 2021</a></h2>
                   
					</div>
                    
					</div>	
                    </li>			
				            
			                        		
               		<li class="portfolio-item2" data-id="id-1" data-type="cat-item-2">	
			        <div>
                   <span class="image-block">
					<a class="image-zoom" href="01.jpg" rel="prettyPhoto[gallery]" title="nagaland"><img width="225" height="140" src="images/thumbs/p2.jpg" alt="nagaland" title="nagaland" />                    
                    </a>
                    </span>
                   <div class="home-portfolio-text">
					<h2 class="post-title-portfolio"><a href="#" rel="bookmark" title="nagaland">&nbsp;&nbsp;Nagaland Tour 2022</a></h2>
                    
					</div>
                    
					</div>	
                    </li>				
				 
                         
			     		              		
               		<li class="portfolio-item2" data-id="id-5" data-type="cat-item-2">	
			        <div>
                   <span class="image-block">
					<a class="image-zoom" href="images/big/pic6.jpg"  title="kerala"><img width="225" height="140" src="images/thumbs/p6.jpg" alt="kerala" title="kerala" />                    
                    </a>
                    </span>
                   <div class="home-portfolio-text">
					<h2 class="post-title-portfolio"><a href="#" rel="bookmark" title="kerala"> &nbsp;&nbsp;Kerala Tour 2023</a></h2>
                   
					</div>
                    
					</div>	
                    </li>			
				            
			     	             	
            
                        <div class="column-clear"></div>
            		</ul>
			<div class="clearfix"></div>
        </div>
    </div>
    



	<div id="footer">
	<h4>+123456789 &bull; <a href="contact-us.php">CKRT Bus Services, Binghamton, New York 13905  </a></h4>
	<p>Hours of Operation&nbsp;&nbsp;&bull;&nbsp;&nbsp;Mon - Sun: 10:00 am - 12:00 am</p>
	<a href="index.php"><img src="output.png"  style="width:200px;
            height:200px"; alt="" /></a>
	<p>&copy; Copyright 2023 CKRT | All Rights Reserved </p>
</div>

</div>
</body>
</html>
