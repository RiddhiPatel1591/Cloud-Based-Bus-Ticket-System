<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Welcome to CKRT Bus Services</title>
<link rel="stylesheet" type="text/css" href="xres/css/style.css" />
<link rel="icon" type="image/png" href="xres/images/favicon.png" />
<link type="text/css" href="css/styles.css" rel="stylesheet" media="all" />
<style>
body {
  background-image: url('download.jpg');background-repeat: no-repeat;
  background-attachment: fixed; 
  background-size: 100% 100%;
}
</style>
</head>

<body>
<div id="wrapper">
	<div id="header">
    
        <ul id="mainnav">
			<li><a href="index.php"style="color:white;">Home</a></li>
            <li><a href="gallery.php"style="color:white;">Gallery</a></li>
            <li class="current"style="color:white;"><a href="history.php">History</a></li>
            <li><a href="routes.php"style="color:white;">Routes</a></li>
            <li><a href="location.php"style="color:white;">location</a></li>
            <li><a href="contact.php"style="color:white;">Contact Us</a></li>
    	</ul>
	</div>
    <div id="content">
    	<div id="gallerycontainer">
			<div class="portfolio-area" style="margin:0 auto; padding:20px 20px 50px 5px; width:820px;">	
			 Double-decker buses and open top buses are commonly used, for providing a good view. Large coaches are used internationally by tour operators, intercity bus lines and charters, for short and long distance destinations. These buses are larger than regular transit buses, with 2 to 4 axles (6 to 10 wheels).
<br>
The history of tour buses in North America began in the early 20th century when trucks were converted to provide a means for sightseeing within large American cities. Gray Line, the largest sightseeing operators, began operations in 1910. Sightseeing was likely a side business for many intercity bus operators because the same types of buses were used (this remains true even today). World War II saw the industry decline, but it slowly re-emerged as an alternative to driving.
<br>
Many musicians, entertainers, dancing crews and bands travel in sleeper buses, commonly referred to as "tour buses". While most if not all of the buses and coaches listed above are for commercial applications, there are many coaches manufactured for personal use as motorhomes. These bus based motorhomes are considered the top end of the RV market.
				<br>
				Volvo Buses (Volvo Bus Corporation / formal name: Volvo Bussar AB) (stylized as VOLVO) is a subsidiary and a business area of the Swedish vehicle maker Volvo, which became an independent division in 1968. It is based in Gothenburg.

It is one of the world's largest bus manufacturers, with a complete range of heavy buses for passenger transportation. The product range includes complete buses and coaches as well as chassis combined with a comprehensive range of services.
<br>
The bus operation has a global presence, with production in Europe, North and South America, Asia and Australia. In India it set up its production facility in Bangalore. A former production facility was located in Irvine, Scotland (closed in 2000).<div class="column-clear"></div>
            </div>
			<div class="clearfix"></div>
        </div>
    </div>
    
<div id="footer">
	<h4>+123456789 &bull; <a href="contact-us.php">CKRT Bus Services, Binghamton, New York 13905  </a></h4>
	<p>Hours of Operation&nbsp;&nbsp;&bull;&nbsp;&nbsp;Mon - Sun: 10:00 am - 12:00 am</p>
	<a href="index.php"><img src="output.png"  style="width:200px;
            height:200px"; alt="" /></a>
	<p>&copy; Copyright 2023 CKRT | All Rights Reserved </p>
</div>

</div>
</body>
</html>
